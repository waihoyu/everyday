# 类 Promise

## 构造函数的参数 fn

## node commonJS 规范
